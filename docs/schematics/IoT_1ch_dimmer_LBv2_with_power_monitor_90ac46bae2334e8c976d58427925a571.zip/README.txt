- Trailing edge MOSFET dimmer for ESP8266 WiFi logic board
- Power monitor (Voltage, current, power, power factor, mains frequency)
- 3.3V isolated power supply for WiFi logic board
- Temperature monitoring
- 100W@120V / 200W@230V in a sealed enclosure            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。